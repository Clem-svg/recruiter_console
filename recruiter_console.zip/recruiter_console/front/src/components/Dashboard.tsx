import React, { useState } from "react";
import Jobs from "../pages/Jobs.tsx";
import Candidates from "../pages/Candidates.tsx";


interface DashboardProps {
  token: string;
}

const Dashboard = ({ token }: DashboardProps) => {
  const [activeTab, setActiveTab] = useState<"jobs" | "candidates">("jobs");
  const [isLoggedIn, setIsLoggedIn] = useState(true);

  const handleLogout = () => {
    localStorage.removeItem("token");
    setIsLoggedIn(false);
    window.location.reload();
  };

  if (!isLoggedIn) return null;

  return (
    <div className="min-vh-100 bg-gray-50" style={{ fontFamily: "Inter, sans-serif" }}>
      {/* Header */}
      <header className="d-flex justify-content-between align-items-center px-5 py-4">
        <h1 className="display-5 m-0 text-dark">Recruiter Console</h1>
      </header>

      {/* Tabs */}
      <div className="d-flex justify-content-start mt-5 mx-5 gap-3">
        <button
          className={`btn btn-lg ${activeTab === "jobs" ? "btn-primary text-white" : "btn-light text-dark"}`}
          onClick={() => setActiveTab("jobs")}
        >
          📝 Mes offre
        </button>
        <button
          className={`btn btn-lg ${activeTab === "candidates" ? "btn-primary text-white" : "btn-light text-dark"}`}
          onClick={() => setActiveTab("candidates")}
        >
          👥 Mes candidats
        </button>
      </div>

      {/* Content */}
      <main className="px-5 py-5">
        {activeTab === "jobs" && <Jobs token={token} />}
        {activeTab === "candidates" && <Candidates token={token} />}
      </main>
    </div>
  );
};

export default Dashboard;
