import React, { useEffect, useState } from "react";
import { Job } from "../types.ts";
import { createJob, updateJob } from "../api/api.tsx";

interface JobModalProps {
  token: string;
  show: boolean;
  onClose: () => void;
  onJobSaved: (job: Job | null) => void;
  jobToEdit?: Job;
  onRequestReload?: () => void;
}

const JobFormModal = ({ token, show, onClose, onJobSaved, jobToEdit, onRequestReload }: JobModalProps) => {
  const [title, setTitle] = useState("");
  const [salaryRange, setSalaryRange] = useState("");
  const [experienceLevel, setExperienceLevel] = useState<number>(0);
  const [category, setCategory] = useState("");
  const [employmentType, setEmploymentType] = useState("");
  const [description, setDescription] = useState("");
  const [benefits, setBenefits] = useState("");
  const [active, setActive] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (jobToEdit) {
      setTitle(jobToEdit.title || "");
      setSalaryRange(jobToEdit.salary_range || "");
      setExperienceLevel(jobToEdit.experience_level || 0);
      setCategory(jobToEdit.category || "");
      setEmploymentType(jobToEdit.employment_type || "");
      setDescription(jobToEdit.description || "");
      setBenefits(jobToEdit.benefits || "");
      setActive(jobToEdit.active ?? true);
    } else {
      setTitle("");
      setSalaryRange("");
      setExperienceLevel(0);
      setCategory("");
      setEmploymentType("");
      setDescription("");
      setBenefits("");
      setActive(true);
    }
    setError("");
  }, [jobToEdit, show]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
  
    if (!title.trim() || !category.trim() || !employmentType.trim()) {
      setError("Veuillez remplir tous les champs obligatoires.");
      return;
    }

    if (experienceLevel < 0) {
      setError("L'expérience ne peut pas être négative");
      return;
    }

    setLoading(true);
    const jobData: Partial<Job> = {
      title,
      salary_range: salaryRange,
      experience_level: experienceLevel,
      category,
      employment_type: employmentType,
      description,
      benefits,
      active,
    };

    try {
      let savedJob: Job;
      if (jobToEdit) {
        savedJob = await updateJob(token, jobToEdit.id, jobData);
      } else {
        savedJob = await createJob(token, jobData);
      }
      onJobSaved(savedJob);
      onRequestReload?.(); 
      onClose();
    } catch (err) {
      alert("Erreur lors de la sauvegarde du job !");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (!show) return null;

  return (
    <div className="modal fade show d-block" style={{ backgroundColor: "rgba(0,0,0,0.5)" }} onClick={onClose}>
      <div className="modal-dialog modal-lg modal-dialog-centered" onClick={(e) => e.stopPropagation()}>
        <div className="modal-content rounded-4 shadow-lg">
          <div className="modal-header border-0">
            <h5 className="modal-title">{jobToEdit ? "Modifier le job" : "Créer un job"}</h5>
            <button type="button" className="btn-close" onClick={onClose}></button>
          </div>

          {error && <div className="alert alert-danger m-3">{error}</div>}

          <form onSubmit={handleSubmit}>
            <div className="modal-body">
              <div className="mb-3">
                <label className="form-label">Titre *</label>
                <input type="text" className="form-control" value={title} onChange={(e) => setTitle(e.target.value)} />
              </div>

              <div className="row mb-3">
                <div className="col">
                  <label className="form-label">Salaire</label>
                  <input type="text" className="form-control" value={salaryRange} onChange={(e) => setSalaryRange(e.target.value)} />
                </div>
                <div className="col">
                  <label className="form-label">Expérience (années)</label>
                  <input
                    type="number"
                    className="form-control"
                    value={experienceLevel}
                    onChange={(e) => setExperienceLevel(Number(e.target.value))}
                    min={0}
                  />
                </div>
              </div>

              <div className="row mb-3">
                <div className="col">
                  <label className="form-label">Catégorie *</label>
                  <input type="text" className="form-control" value={category} onChange={(e) => setCategory(e.target.value)} />
                </div>
                <div className="col">
                  <label className="form-label">Type d'emploi *</label>
                  <select className="form-select" value={employmentType} onChange={(e) => setEmploymentType(e.target.value)}>
                    <option value="">Sélectionner</option>
                    <option value="CDI">CDI</option>
                    <option value="CDD">CDD</option>
                    <option value="Freelance">Freelance</option>
                    <option value="Alternance">Alternance</option>
                  </select>
                </div>
              </div>

              <div className="mb-3">
                <label className="form-label">Description</label>
                <textarea className="form-control" value={description} onChange={(e) => setDescription(e.target.value)} />
              </div>

              <div className="mb-3">
                <label className="form-label">Avantages</label>
                <textarea className="form-control" value={benefits} onChange={(e) => setBenefits(e.target.value)} />
              </div>

              <div className="form-check mb-3">
                <input className="form-check-input" type="checkbox" checked={active} onChange={(e) => setActive(e.target.checked)} id="activeCheck" />
                <label className="form-check-label" htmlFor="activeCheck">Actif</label>
              </div>
            </div>

            <div className="modal-footer border-0 d-flex justify-content-between">
              <button type="button" className="btn btn-secondary" onClick={onClose}>Annuler</button>
              <button type="submit" className="btn btn-dark" disabled={loading}>{loading ? "En cours..." : jobToEdit ? "Mettre à jour" : "Créer"}</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default JobFormModal;
