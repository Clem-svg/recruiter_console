import React, { useState } from "react";
import { Job } from "../types.ts";
import { updateJob } from "../api/api.tsx";

interface JobCardProps {
  job: Job;
  token: string;
  onJobUpdated: (job: Job | null) => void;
  onJobDeleted: (jobId: number) => void;
  onEdit: (job: Job) => void;
  onRequestReload?: () => void;
}

const JobCard = ({ job, token, onJobUpdated, onJobDeleted, onEdit, onRequestReload }: JobCardProps) => {
  const [archiving, setArchiving] = useState(false);

  const handleArchive = async () => {
    if (!window.confirm("Voulez-vous vraiment archiver ce job ?")) return;
    setArchiving(true);
    try {
      const updatedJob = await updateJob(token, job.id, { active: false });
      onJobUpdated(updatedJob);
      onRequestReload?.();
    } catch {
      alert("Erreur lors de l'archivage !");
    } finally {
      setArchiving(false);
    }
  };

  return (
    <div className="col-md-3">
      <div className="card h-100 shadow-sm rounded-3">
        <div className="card-body d-flex flex-column">
          <h5 className="card-title">{job.title}</h5>
          <p className="card-text mb-1"><strong>Catégorie:</strong> {job.category}</p>
          <p className="card-text mb-1"><strong>Type:</strong> {job.employment_type}</p>
          <p className="card-text mb-1"><strong>Salaire:</strong> {job.salary_range}</p>
          <p className="card-text mb-1"><strong>Expérience:</strong> {job.experience_level} ans</p>
          <p className="card-text mb-1"><strong>Créé le:</strong> {new Date(job.created_at).toLocaleDateString()}</p>

          {job.description && (
            <p className="card-text" style={{ whiteSpace: "pre-wrap" }}>
              <strong>Description:</strong> {job.description}
            </p>
          )}

          {job.benefits && (
            <p className="card-text" style={{ whiteSpace: "pre-wrap" }}>
              <strong>Avantages:</strong> {job.benefits}
            </p>
          )}

          <div className="mt-auto d-flex justify-content-end gap-2">
            <span style={{ cursor: "pointer" }} title="Modifier" onClick={() => onEdit(job)}>✏️</span>
            <span style={{ cursor: "pointer" }} title="Archiver" onClick={handleArchive}>
              {archiving ? "⏳" : "🗄️"}
            </span>
            <span style={{ cursor: "pointer" }} title="Supprimer" onClick={() => onJobDeleted(job.id)}>🗑️</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobCard;
