import React, { useEffect, useState } from "react";
import { Job } from "../types.ts";
import { getJobs, deleteJob } from "../api/api.tsx";
import JobFormModal from "../components/JobFormModal.tsx";
import JobCard from "../components/JobCard.tsx";

interface JobsProps {
  token: string;
}

export default function Jobs({ token }: JobsProps) {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingJob, setEditingJob] = useState<Job | undefined>(undefined);
  const [search, setSearch] = useState("");

  const fetchJobs = async (query = "") => {
    setLoading(true);
    try {
      const data = await getJobs(token, query);
      setJobs(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // initial fetch
  useEffect(() => {
    if (!token) return;
    fetchJobs();
  }, [token]);

  // Search
  useEffect(() => {
    const delay = setTimeout(() => {
      fetchJobs(search);
    }, 300); 

    return () => clearTimeout(delay);
  }, [search, token]);

  const handleJobSaved = () => {
    fetchJobs(search);
  };

  const handleJobDeleted = async (jobId: number) => {
    if (!window.confirm("Voulez-vous vraiment supprimer ce job ?")) return;
    try {
      await deleteJob(token, jobId);
      fetchJobs(search);
    } catch (err) {
      alert("Erreur lors de la suppression !");
      console.error(err);
    }
  };

  const handleEdit = (job: Job) => {
    setEditingJob(job);
    setShowModal(true);
  };

  if (loading) return <div className="text-center mt-5">Chargement des jobs...</div>;

  return (
    <div className="container mt-4">
      <div className="d-flex justify-content-between align-items-center mb-3">
        <h2 className="mb-0">Mes Jobs</h2>
        <button
          className="btn btn-outline-success"
          onClick={() => {
            setEditingJob(undefined);
            setShowModal(true);
          }}
        >
          Nouvelle offre
        </button>
      </div>

      {/* Search bar */}
      <div className="mb-3">
        <input
          type="text"
          className="form-control"
          placeholder="Rechercher un job..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      <div className="row g-3">
        {jobs.map((job) => (
          <JobCard
            key={job.id}
            job={job}
            token={token}
            onJobUpdated={handleJobSaved}
            onJobDeleted={handleJobDeleted}
            onEdit={handleEdit}
            onRequestReload={() => fetchJobs(search)}
          />
        ))}
      </div>

      <JobFormModal
        token={token}
        show={showModal}
        onClose={() => setShowModal(false)}
        onJobSaved={handleJobSaved}
        jobToEdit={editingJob}
        onRequestReload={() => fetchJobs(search)}
      />
    </div>
  );
}
