import React, { useState } from "react";
import API from "../api/api.tsx";

interface LoginProps {
  onLogin: (token: string) => void;
}

const Login = ({ onLogin }: LoginProps) => {
  const [email, setEmail] = useState<string>("");
  const [password, setPassword] = useState<string>("");
  const [error, setError] = useState<string>("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!email.trim() || !password.trim()) {
      setError("Veuillez remplir tous les champs.");
      return;
    }
  
    try {
      const res = await API.post("/login", {
        recruiter: { email, password },
      });
  
      const token = res.data.token;
      localStorage.setItem("token", token);
      onLogin(token);
    } catch (err) {
      setError("Email ou mot de passe invalide");
      console.error(err);
    }
  };

  return (
    <div className="d-flex justify-content-center align-items-center vh-100">
      <div className="card p-5 shadow-lg rounded-4" style={{ minWidth: "350px", maxWidth: "400px" }}>
        <h1 className="text-center mb-4 fw-bold">Connexion Recruteur</h1>

        {error && (
          <div className="alert alert-danger py-2 px-3 mb-3" role="alert">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} noValidate>
          <div className="mb-3">
            <label htmlFor="email" className="form-label fw-semibold">
              Email
            </label>
            <input
              id="email"
              type="email"
              className={`form-control ${error && !email ? "is-invalid" : ""}`}
              placeholder="votre email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div className="mb-4">
            <label htmlFor="password" className="form-label fw-semibold">
              Mot de passe
            </label>
            <input
              id="password"
              type="password"
              className={`form-control ${error && !password ? "is-invalid" : ""}`}
              placeholder="********"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          <button
            type="submit"
            className="btn btn-primary w-100 py-2 fw-bold"
          >
            Se connecter
          </button>
        </form>
      </div>
    </div>
  );
};

export default Login;
