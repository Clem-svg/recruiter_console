import React, { useEffect, useState } from "react";
import { getCandidates } from "../api/api.tsx";
import { Candidate } from "../types.ts";

interface CandidatesProps {
  token: string;
}

export default function Candidates({ token }: CandidatesProps) {
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string>("");

  useEffect(() => {
    async function fetchCandidates() {
      try {
        const data = await getCandidates(token);
        setCandidates(data);
      } catch (err) {
        console.error(err);
        setError("Impossible de charger les candidats.");
      } finally {
        setLoading(false);
      }
    }
    fetchCandidates();
  }, [token]);

  if (loading)
    return <div className="text-center mt-5">Chargement des candidats...</div>;
  if (error) return <div className="alert alert-danger mt-5">{error}</div>;

  return (
    <div className="container mt-4">
      <h2 className="mb-4 fw-bold">Candidats</h2>
      <div className="row g-3">
        {candidates.map((c) => (
          <div key={c.id} className="col-lg-3 col-md-4 col-sm-6">
            <div className="card h-100 shadow-sm rounded-3">
              <div className="d-flex justify-content-center mt-3">
                <img
                  src={c.avatar || "https://via.placeholder.com/100"}
                  alt={c.name}
                  className="rounded-circle"
                  style={{ width: "100px", height: "100px", objectFit: "cover" }}
                />
              </div>
              <div className="card-body d-flex flex-column text-center">
                <h5 className="card-title fw-semibold">{c.name}</h5>
                <p className="card-text text-muted mb-1" style={{ fontSize: "0.85rem" }}>
                  {c.email}
                </p>
                <p className="card-text mb-3" style={{ fontSize: "0.85rem" }}>
                  <strong>Location:</strong> {c.location || "N/A"}
                </p>
                <div className="mt-auto d-flex justify-content-center">
                  <a
                    href={`mailto:${c.email}?subject=Contacter`}
                    className="btn btn-outline-dark btn-sm px-3"
                  >
                    Contacter
                  </a>
                </div>             
               </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
