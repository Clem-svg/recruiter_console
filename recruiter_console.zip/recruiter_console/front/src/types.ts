export interface Job {
    id: number;
    title: string;
    salary_range: string;
    experience_level: number;
    category: string;
    employment_type: string;
    description: string;
    benefits: string;
    active: boolean;
    created_at: string;
  }

  export interface Candidate {
    id: string;
    name: string;
    email: string;
    avatar?: string;
    location?: string;
  }
  