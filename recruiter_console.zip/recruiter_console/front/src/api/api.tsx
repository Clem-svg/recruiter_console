import axios from "axios";
import { Job, Candidate } from "../types";

const API = axios.create({
  baseURL: "http://localhost:3000", // backend Rails
});

// Login
export const login = async (email: string, password: string) => {
  try {
    const res = await API.post("/login", { email, password });
    return res.data;
  } catch (err) {
    throw err;
  }
};

// Fetch recruiter's jobs
export const getJobs = async (token: string, query: string = ""): Promise<Job[]> => {
  const params = query ? `?query=${encodeURIComponent(query)}` : "";
  const res = await API.get<Job[]>(`/jobs${params}`, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
  return res.data;
};

// New Job
export const createJob = async (token: string, jobData: Partial<Job>) => {
  try {
    const res = await API.post<{ job: Job }>(
      "/jobs",
      { job: jobData },
      {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      }
    );
    return res.data.job;
  } catch (err) {
    throw err;
  }
};

// Update Job
export const updateJob = async (token: string, jobId: number, jobData: Partial<Job>) => {
  try {
    const res = await API.patch<{ job: Job }>(
      `/jobs/${jobId}`,
      { job: jobData },
      {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      }
    );
    return res.data.job;
  } catch (err) {
    throw err;
  }
};

// Fetch  fake candidates
export const getCandidates = async (token: string): Promise<Candidate[]> => {
  try {
    const response = await API.get<Candidate[]>("/candidates", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return response.data;
  } catch (err) {
    console.error("Erreur lors de la récupération des candidats:", err);
    throw err;
  }
};

export const deleteJob = async (token: string, jobId: number): Promise<void> => {
  try {
    await API.delete(`/jobs/${jobId}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
  } catch (err) {
    console.error("Erreur lors de la suppression du job :", err);
    throw err;
  }
};

export default API;
