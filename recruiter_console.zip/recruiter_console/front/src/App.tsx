import React, { useState } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import Login from "./pages/Login.tsx";
import Dashboard from "./components/Dashboard.tsx";

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(!!localStorage.getItem("token"));

  const handleLogout = () => {
    localStorage.removeItem("token");
    setIsAuthenticated(false);
  };

  const [token, setToken] = useState<string>(localStorage.getItem("token") || "");

  return (
  <Router>
    <>
      {/* Navbar */}
      {isAuthenticated && (
        <div className="container mt-4 d-flex justify-content-end">
          <button className="btn btn-danger" onClick={handleLogout}>
           ⏻
          </button>
        </div>
      )}

      <div className="container mt-3">
      <Routes>
        {isAuthenticated ? (
          <>
            <Route path="/" element={<Dashboard token={token} />} />
            <Route path="*" element={<Navigate to="/" />} />
          </>
        ) : (
          <>
            <Route
              path="/login"
              element={
                <Login
                  onLogin={(newToken) => {
                    setToken(newToken);
                    setIsAuthenticated(true);
                  }}
                />
              }
            />
            <Route path="*" element={<Navigate to="/login" />} />
          </>
        )}
      </Routes>
      </div>
    </>
  </Router>
  );
}

export default App;
