class SessionsController < ApplicationController
    skip_before_action :authenticate_recruiter_from_token!
  
    def create
        recruiter_params = params.require(:recruiter).permit(:email, :password)
        recruiter = Recruiter.find_by(email: recruiter_params[:email])
      
        if recruiter&.valid_password?(recruiter_params[:password])
          token = Warden::JWTAuth::UserEncoder.new.call(recruiter, :recruiter, nil)[0]
          render json: { token: token }
        else
          render json: { error: 'Invalid email or password' }, status: :unauthorized
        end
      end
      
  end
  