class ApplicationController < ActionController::API
  before_action :authenticate_recruiter_from_token!

  private

  def authenticate_recruiter_from_token!
    auth_header = request.headers['Authorization']
    return head :unauthorized unless auth_header&.start_with?('Bearer ')

    token = auth_header.split(' ').last

    begin
      payload = Warden::JWTAuth::TokenDecoder.new.call(token)
      @current_recruiter = Recruiter.find(payload['sub'])
    rescue ActiveRecord::RecordNotFound, JWT::DecodeError
      head :unauthorized
    end
  end

  def current_recruiter
    @current_recruiter
  end
end

