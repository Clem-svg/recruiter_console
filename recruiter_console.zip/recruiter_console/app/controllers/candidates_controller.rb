require 'net/http'
require 'uri'
require 'json'

class CandidatesController < ApplicationController
  def index
    url = URI("https://randomuser.me/api/?results=20&nat=fr")
    res = Net::HTTP.get(url)
    data = JSON.parse(res)["results"]

    candidates = data.map.with_index(1) do |c, i|
      {
        id: i,
        avatar: c['picture']['large'],
        name: "#{c['name']['first']} #{c['name']['last']}",
        email: c['email'],
        location: c['location']['city']
      }
    end

    render json: candidates
  end
end

