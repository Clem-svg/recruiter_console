class JobsController < ApplicationController
  before_action :authenticate_recruiter_from_token!
  before_action :set_job, only: %i[show update destroy]

  # GET /jobs
  def index
    if params[:query].present?
      q = "%#{params[:query]}%"
      @jobs = Job.where(active: true)
                 .where("title LIKE ? OR description LIKE ? OR benefits LIKE ? OR category LIKE ?", q, q, q, q)
    else
      @jobs = Job.where(active: true)
    end

    render json: @jobs
  end

  # GET /jobs/1
  def show
    render json: @job
  end

  # POST /jobs
  def create
    return render json: { error: "Unauthorized" }, status: :unauthorized unless current_recruiter

    @job = current_recruiter.jobs.new(job_params)
    if @job.save
      render json: @job, status: :created
    else
      render json: { errors: @job.errors.full_messages }, status: :unprocessable_entity
    end
  end

  # PATCH/PUT /jobs/1
  def update
    if @job.update(job_params)
      render json: @job
    else
      render json: @job.errors, status: :unprocessable_entity
    end
  end

  # DELETE /jobs/1
  def destroy
    @job.destroy!
    head :no_content
  end

  private

  def set_job
    @job = current_recruiter.jobs.find(params[:id])
  end

  def job_params
    params.require(:job).permit(
      :title,
      :salary_range,
      :experience_level,
      :category,
      :employment_type,
      :description,
      :benefits,
      :active
    )
  end

  def authenticate_recruiter_from_token!
    header = request.headers['Authorization']
    token = header.split(' ').last if header.present?
    return head :unauthorized unless token

    begin
      payload = JWT.decode(token, 'test_secret_key', true, algorithm: 'HS256')[0]
      @current_recruiter = Recruiter.find(payload['sub'])
    rescue JWT::DecodeError
      head :unauthorized
    end
  end

  def current_recruiter
    @current_recruiter
  end
end
