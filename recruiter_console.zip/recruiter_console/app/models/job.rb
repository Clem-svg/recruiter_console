class Job < ApplicationRecord
    validates :salary_range, :experience_level, :category, :employment_type, presence: true
    belongs_to :recruiter
end
  