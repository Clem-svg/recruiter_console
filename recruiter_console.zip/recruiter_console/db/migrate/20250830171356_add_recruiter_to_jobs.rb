class AddRecruiterToJobs < ActiveRecord::Migration[7.2]
  def change
    add_reference :jobs, :recruiter, null: false, foreign_key: true
  end
end
