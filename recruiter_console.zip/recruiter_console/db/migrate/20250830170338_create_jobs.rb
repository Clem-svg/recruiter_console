class CreateJobs < ActiveRecord::Migration[7.2]
  def change
    create_table :jobs do |t|
      t.string :title
      t.string :salary_range, null: false
      t.integer :experience_level, null: false
      t.string :category, null: false
      t.string :employment_type, null: false
      t.text :description
      t.text :benefits
      t.boolean :active, default: true

      t.timestamps
    end
  end
end
