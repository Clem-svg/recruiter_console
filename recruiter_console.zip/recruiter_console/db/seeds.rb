# db/seeds.rb

Job.destroy_all
Recruiter.destroy_all

recruiter = Recruiter.create!(
  email: "demo@recruiter.com",
  password: "passwordCyberSecu1234"
)

puts "Recruteur créé"


# Crée 3 jobs associés à ce recruteur
Job.create!([
  {
    title: "Développeur Frontend React",
    salary_range: "35k-45k",
    experience_level: 2,
    category: "Informatique",
    employment_type: "CDI",
    description: "Développement d'interfaces utilisateurs modernes en React.",
    benefits: "Tickets restaurant, télétravail partiel",
    active: true,
    recruiter: recruiter
  },
  {
    title: "Ingénieur DevOps",
    salary_range: "50k-65k",
    experience_level: 4,
    category: "Informatique",
    employment_type: "CDI",
    description: "Automatisation des déploiements et gestion des serveurs cloud.",
    benefits: "Mutuelle, formation continue, RTT",
    active: true,
    recruiter: recruiter
  },
  {
    title: "Chef de projet digital",
    salary_range: "45k-55k",
    experience_level: 3,
    category: "Gestion / Management",
    employment_type: "CDD",
    description: "Coordination des projets digitaux et suivi des équipes.",
    benefits: "Tickets restaurant, primes sur objectifs",
    active: true,
    recruiter: recruiter
  }
])

puts "3 jobs ont été créés"
